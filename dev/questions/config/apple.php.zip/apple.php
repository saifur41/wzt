<?php
$db=new mysqli('localhost','root','root','checkmate_api');

if($db->connect_errno){
    echo 'Db connection error-'.$db->connect_error;
}


/// Fetch ///
$res=$db->query(" SELECT * FROM `user` WHERE id=2");
$res2=$res->fetch_assoc();
 // if(nlll!=={
 //    print_r($data); die;  
 // }else{
 // echo ''
 // }
 //print_r($res2);// die;  




?>